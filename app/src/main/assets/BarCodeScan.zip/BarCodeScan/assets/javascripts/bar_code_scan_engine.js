/**
 * @name scan bar code engine
 * @version 0.0.1
 * @requires jQuery v1.2.3+
 * @license MIT License - http://www.opensource.org/licenses/mit-license.php
 *
 */
(function() {
  window.BarCodeScanEngine = {
    // {
    //      chart: {
    //        title: "商品名称",
    //        data: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
    //        xAxis: ["5/31", "6/14", "6/27", "7/9", "7/20", "7/30", "8/8", "8/16", "8/23", "8/29", "9/3", "9/7", "9/10", "9/12", "9/13"],
    //      },
    //      tabs: [
    //          {
    //              title: "概况",
    //              table: {
    //                  length: 2,
    //                  0: ["标题 1", "标题 2", "标题 3"],
    //                  1: ["行 1 数据 1", "行 1 数据 2", "行 3 数据 3"],
    //                  2: ["行 2 数据 1", "行 2 数据 2", "行 3 数据 3"]
    //              }
    //          },
    //          {
    //              title: "同区情况",
    //              table: {
    //                  length: 2,
    //                  0: ["标题一", "标题二", "标题三"],
    //                  1: ["行一数据一", "行一数据二", "行三数据三"],
    //                  2: ["行二数据一", "行二数据二", "行三数据三"]
    //              }
    //          },
    //          {
    //              title: "other",
    //              table: {
    //                length: 0
    //              }
    //          }
    //      ],
    //      timestmap: '12/23/45 67:89'
    //  };
    generateTable: function(tableData) {
      var tmpArray = [], htmlString;

      if(tableData === null || tableData === undefined) {
        return "图表数据为空";
      }

      htmlString = "<table class='table table-striped table-bordered'>"

      if(tableData["0"] !== null && tableData["0"] !== undefined) {
        htmlString += "<thead><th>" + tableData["0"].join("</th><th>") + "</th></thead>";
      }

      for(var i = 1, len = tableData.length; i <= len; i ++) {
        tmpArray.push("<tr><td>" + tableData[i].join("</td><td>") + "</td></tr>");
      }

      htmlString += "<tbody>" + tmpArray.join("") + "</tbody>";
      htmlString += "</table>";

      return htmlString;
    },
    generateTabs: function(tabsData) {
      var tmpArray = [],
          htmlString, i, len;

      for(i = 0, len = tabsData.length; i < len; i ++) {
        tmpArray.push("<li class='" + (i === 0 ? "active" : "") + "'>\
                        <a data-toggle='tab' href='#tab_" + i + "'>" + tabsData[i].title + "</a>\
                      </li>");
      }

      htmlString = "<ul class='nav nav-tabs' style='background-color:#2ec7c9;'>" +
                     tmpArray.join("") +
                   "</ul>";

      // clear array
      tmpArray.length = 0;
      for(i = 0, len = tabsData.length; i < len; i ++) {
        tmpArray.push("<div id='tab_" + i + "' class='tab-pane animated fadeInUp " + (i === 0 ? "active" : "") + "'>\
                        <div class='row'  style='margin-left:0px;margin-right:0px'>\
                          <div class='col-lg-12' style='padding-left:0px;padding-right:0px'>\
                            <table class='table table-striped table-bordered table-hover'>"
                              + BarCodeScanEngine.generateTable(tabsData[i].table) +
                            "</table>\
                          </div>\
                        </div>\
                      </div>");
      }

      htmlString += "<div class='tab-content tabs-flat no-padding'>" +
                      tmpArray.join("") +
                    "</div>";

      return "\
      <div class='row tab-part tab-part-'  style='margin-left:0px;margin-right:0px'>\
        <div class='col-xs-12'  style='padding-left:0px;padding-right:0px'>\
          <div class='dashboard-box'>\
            <div class='box-tabbs'>\
              <div class='tabbable'>"
                + htmlString + "\
              </div>\
              \
            </div>\
          </div>\
        </div>\
      </div>";
    },
    generateChart: function(option) {
      if(option.data === null || option.data === undefined) {
        option.data = [];
        for(var i = 0, len = 15; i < len; i++) { option.data[i] = 0; }
      }

      while(option.data.length < 15) { option.data.push(0); }

      if(option.data.length > 15) {
        var newData = [];
        for(var i = 0, len = 15; i < len; i++) { newData[i] = option.data[i]; }

        option.data = newData;
      }

      var chartOption = {
        title: {
          text: option.title,
          left: 'center'
        },
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            x: 'right',
            y: 'top',
            data: [""],
        },
        toolbox: {
            show : false,
            x: 'right',
            y: 'top',
            feature : {
                mark : {show: true},
                dataView : {show: true, readOnly: false},
                magicType : {show: true, type: ['line']},
                restore : {show: true},
                saveAsImage : {show: false}
            }
        },
        calculable: true,
        grid: {
          show:true,
          backgroundColor:'transparent',
          y: 30, y2:20, x2:0, x:35
        },
        xAxis : [
           {
                type : 'category',
                boundaryGap : true,
                splitLine:{ show:false },
                axisTick: { show:false },
                data : option.xAxis
            }
        ],
        yAxis : [{
          "type": "value",
          "name": "",
          nameTextStyle: { color:'#323232' }
        }],
        series: option.series
      };
      var chart = echarts.init(document.getElementById("bannerChart"), 'macarons');
      chart.setOption(chartOption);
    },
    parse: function(data) {
      BarCodeScanEngine.generateChart(data.chart);

      var tabContent = document.getElementById("tabContent");
      tabContent.innerHTML += BarCodeScanEngine.generateTabs(data.tabs);

      if(typeof(data.timestamp) !== 'undefined') {
        var timestamp = document.getElementById("timestamp");
        timestamp.innerHTML = "数据更新时间:" + data.timestamp;
      }
    }
  };
}).call(this);
