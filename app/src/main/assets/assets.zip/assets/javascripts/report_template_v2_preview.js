/* jslint plusplus: true */
/* global
     $:false,
     ReportTemplateV2:false,
     TemplateData:false,
     echarts:false
*/
/*
  version: 2.0.0
  author: jay_li@intfocus.com
  date: 16/04/23
  change log:

  16/05/08:
    add: echart component type#`pie`
    fixed: tab switch with hidden other tab-part-*
 */

(function(){

  "use strict";

  window.ReportTemplateV2 = {
    charts: [],
    screen: function() {
        var w = window,
        d = document,
        e = d.documentElement,
        obj = {}; // new Object(); // The object literal notation {} is preferable.
        obj.width = w.innerWidth || e.innerWidth;
        obj.height = w.innerHeight || e.innerHeight;
        return obj;
    },
    modal: function(ctl, type) {
        var date1 = new Date().getTime(),
            $modal = $("#ReportTemplateV2Modal");

        $modal.modal("show");
        console.log(type);

        if(type === 'info') {
          $modal.find(".modal-title").html($(ctl).data("title"));
          $modal.find(".modal-body").html($(ctl).data("content"));
        }
        else if(type === 'search') {
          $modal.find(".modal-title").html("选择门店");
          var items = [], itemName;
          for(var i = 0, len = window.TemplateDatas.length; i < len; i++) {
            itemName = window.TemplateDatas[i].name;
            items.push("<a href='javascript:void(0);' onclick='ReportTemplateV2.setSelectedItem(\"" + itemName + "\")'>" + itemName + "</a>");
          }

          $modal.find(".modal-body").html(items.join("<br>"));
        }
        else {
          console.log("unkown type: " + type);
        }
        var date2 = new Date().getTime(),
            dif = date2 - date1;
        console.log("duration: " + dif);
    },
    outerApi: function(ctl) {
      var $modal = $("#ReportTemplateV2Modal"),
          url = $(ctl).data("url"),
          split = url.indexOf("?") > 0 ? "&" : "?";

      url = url + split + $(ctl).data("params");

      $modal.modal("show");
      $modal.find(".modal-title").html($(ctl).data("title"));

      $.ajax({
        type: "GET",
        url: url,
        success:function(result, status, xhr) {
          $modal.find(".modal-body").html("loading...");

          try {
              var contentType = xhr.getResponseHeader("content-type") || "default-not-set",
                  table = "<table id='modalContentTable' class='table'><tbody>";

              $("#contentType").html(contentType);
              if(contentType.toLowerCase().indexOf("application/json") < 0) {
                table = table + "<tr><td style='width:30%;'>提示</td><td style='width:70%;'>content-type 有误</td></tr>";
                table = table + "<tr><td style='width:30%;'>期望值</td><td style='width:70%;'>application/json</td></tr>";
                table = table + "<tr><td style='width:30%;'>响应值</td><td style='width:70%;'>" + contentType + "</td></tr>";
                table = table + "</tbody></table>";

                $modal.find(".modal-body").html(table);
                return;
              }

              var json = JSON.parse(JSON.stringify(result)),
                  regPhone1 = /^1\d{10}$/,
                  regPhone2 = /^0\d{2,3}-?\d{7,8}$/,
                  regEmail = /^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/;

              if(result === null || result.length === 0) {
                table = table + "<tr><td style='width:30%;'>响应</td><td style='width:70%;'>内容为空</td></tr>"
                table = table + "<tr><td style='width:30%;'>链接</td><td style='width:70%;word-break:break-all;'>" + url + "</td></tr>"
              }

              for(var key in json) {
                var value = json[key];
                if(regPhone1.test(value) || regPhone2.test(value)) {
                  value = "<a class='sms' href='tel:" + value + "'>" + value + "</a>&nbsp;&nbsp;&nbsp;&nbsp;" +
                          "<a class='tel' href='sms:" + value + "'> 短信 </a>";
                }
                else if(regEmail.test(value)) {
                  value = "<a class='mail' href='mailto:'" + value + "'>" + value + "</a>";
                }
                table = table + "<tr><td style='width:30%;'>" + key + "</td><td style='width:70%;'>" +value + "</td></tr>";
              }
              table = table + "</tbody></table>";

              $modal.find(".modal-body").html(table);
          } catch (e) {
              console.log(e);
              $modal.find(".modal-body").html("response:\n" + JSON.stringify(result) + "\nerror:\n" + e);
          }

          // modal width should equal or thinner than screen
          var width = ReportTemplateV2.screen().width - 10;
          $("#modalContentTable").css("max-width", width + "px");
        },
        error:function(XMLHttpRequest, textStatus, errorThrown) {
              $modal.find(".modal-body").html("GET " + url + "<br>状态:" + textStatus + "<br>报错:" + errorThrown);
        }
      });
    },
    checkArrayForChart: function(array) {
        for(var index = 0, len = array.length; index < len; index ++) {
          if(array[index] === null) {
            array[index] = undefined;
          }
        }
        return array;
    },
    generateTable: function(heads, rows, outerApi) {
      var tmpArray = [],
          isOuterAapi = (typeof(outerApi) !== 'undefined'),
          htmlString;

      for(var index = 0, len = heads.length; index < len; index ++) {
        tmpArray.push(heads[index]);
      }
      htmlString = "<thead><th>" + tmpArray.join("</th><th>") + "</th></thead>";

      // clear array
      tmpArray.length = 0;
      for(var rowIndex = 0, rowLen = rows.length; rowIndex < rowLen; rowIndex ++) {
        var row = rows[rowIndex],
            isRoot = (row[0] === 1 || row[0] === "1"),
            rowString;

        for(var dataIndex = 1, dataLen = row.length; dataIndex < dataLen; dataIndex ++) {
          var data = row[dataIndex];

          if(isOuterAapi && !isRoot && outerApi.target === dataIndex) {
            data = "<a href='javascript:void(0);' onclick='ReportTemplateV2.outerApi(this);' " +
                   "data-title='" + data + "' " +
                   "data-url='" + outerApi.url + "' " +
                   "data-params='" + outerApi.data[rowIndex] + "'>" + data +
                   "</a>";
          }

          if(dataIndex === 1) {
            rowString = (isRoot ? "\
              <tr>\
                <td>\
                  <a href='#' class='table-more table-more-closed'>"
                    + data +
                  "</a>\
                </td>"
                :
              "<tr class='more-items' style='display:none'> \
                <td>&nbsp;&nbsp;&nbsp;"
                  + data +
                "</td>");
          }
          else {
            rowString += "<td>" + data + "</td>";
          }
        }
        rowString += "</tr>";

        tmpArray.push(rowString);
      }
      htmlString += "<tbody>" + tmpArray.join("") + "</tbody>";

      return htmlString;
    },
    generateTables: function(outerIndex, innerIndex, tabs) {
      var tabIndex = (new Date()).valueOf() + outerIndex * 1000 + innerIndex,
          tmpArray = [],
          htmlString, i, len;

      for(i = 0, len = tabs.length; i < len; i ++) {
        tmpArray.push("<li class='" + (i === 0 ? "active" : "") + "'>\
                        <a data-toggle='tab' href='#tab_" + tabIndex + "_" + i + "'>" + tabs[i].title + "</a>\
                      </li>");
      }
      htmlString = "<ul class='nav nav-tabs' style='background-color:#2ec7c9;'>" +
                     tmpArray.join("") +
                   "</ul>";

      // clear array
      tmpArray.length = 0;
      for(i = 0, len = tabs.length; i < len; i ++) {
        tmpArray.push("<div id='tab_" + tabIndex + "_" + i + "' class='tab-pane animated fadeInUp " + (i === 0 ? "active" : "") + "'>\
                        <div class='row'  style='margin-left:0px;margin-right:0px'>\
                          <div class='col-lg-12' style='padding-left:0px;padding-right:0px'>\
                            <table class='table table-striped table-bordered table-hover'>"
                              + ReportTemplateV2.generateTable(tabs[i].table.head, tabs[i].table.data, tabs[i].outer_api) +
                            "</table>\
                          </div>\
                        </div>\
                      </div>");
      }
      htmlString += "<div class='tab-content tabs-flat no-padding'>" +
                      tmpArray.join("") +
                    "</div>";

      return "\
      <div class='row tab-part tab-part-" + outerIndex + "'  style='margin-left:0px;margin-right:0px'>\
        <div class='col-xs-12'  style='padding-left:0px;padding-right:0px'>\
          <div class='dashboard-box'>\
            <div class='box-tabbs'>\
              <div class='tabbable'>"
                + htmlString + "\
              </div>\
              \
            </div>\
          </div>\
        </div>\
      </div>";
    },

    // after require echart.js
    // `innerIndex` = outerIndex * index
    generateChart: function(outerIndex, innerIndex, config) {
      ReportTemplateV2.charts.push({ index: innerIndex, options: ReportTemplateV2.generateChartOptions(config) });
      return "\
      <div class='row tab-part tab-part-" + outerIndex + "'  style='margin-left:0px;margin-right:0px'>\
        <div class='widget'>\
          <div class='widget-body'>\
            <div class='row'>\
              <div class='col-sm-12'  style='padding-left:0px;padding-right:0px'>\
                <div id='template_chart_" + innerIndex + "' class='chart chart-lg'></div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>";
    },
    generateChartOptions: function(option) {
      var chart_type = option.chart_type,
          chart_option;
      if(chart_type === 'pie') {
        chart_option = {
          tooltip: {
              trigger: 'item',
              formatter: "{a} <br/>{b}: {c} ({d}%)"
          },
          legend: {
              orient: 'vertical',
              x: 'left',
              data: option.legend
          },
          series: [
            {
              name:option.title,
              type:'pie',
              radius: ['50%', '70%'],
              avoidLabelOverlap: false,
              label: {
                  normal: {
                      show: false,
                      position: 'center'
                  },
                  emphasis: {
                      show: true,
                      textStyle: {
                          fontSize: '30',
                          fontWeight: 'bold'
                      }
                  }
              },
              labelLine: {
                  normal: {
                      show: false
                  }
              },
              itemStyle: {
                  normal: {
                      shadowBlur: 200,
                      shadowColor: 'rgba(0, 0, 0, 0.5)'
                  }
              },
              data: option.data
            }
          ]
        };
        console.log(JSON.stringify(chart_option));
      }
      else {
        var seriesColor = ['#96d4ed', '#fe626d', '#ffcd0a', '#fd9053', '#dd0929', '#016a43', '#9d203c', '#093db5', '#6a3906', '#192162'];
        for(var i = 0, len = option.series.length; i < len; i ++) {
            option.series[i].data = ReportTemplateV2.checkArrayForChart(option.series[i].data);
            option.series[i].itemStyle = { normal: { color: seriesColor[i] } };
        }
        var yAxis;
        for(var i = 0, len = option.yAxis.length; i < len; i ++) {
           yAxis = option.yAxis[i];
           yAxis.nameTextStyle = { color:'#323232' /*cbh*/ };
           option.yAxis[i] = yAxis;
        }

        chart_option = {
          tooltip : {
              trigger: 'axis'
          },
          legend: {
              x: 'center',
              y: 'top',
              data: option.legend
          },
          toolbox: {
              show : false,
              x: 'right',
              y: 'top',
              feature : {
                  mark : {show: true},
                  dataView : {show: true, readOnly: false},
                  magicType : {show: true, type: ['line', 'bar']},
                  restore : {show: true},
                  saveAsImage : {show: false}
              }
          },
          calculable : true,
          grid: {y: 17, y2:20, x2:2, x:40},
          xAxis : [
              {
                  type : 'category',
                  boundaryGap : true,
                  splitLine:{
                    show:false,
                  },
                  axisTick: {
                    show:false,/*cbh*/
                  },
                  data : option.xAxis
              }
          ],
          yAxis : option.yAxis,
          series : option.series
        };
      }

      return chart_option;
    },
    generateBanner: function(outerIndex, innerIndex, config) {
      var modelTitle = "说明";
      if(config.title.length) {
        modelTitle = config.title;
      }
      return "\
      <div class='row tab-part tab-part-" + outerIndex + "' style='margin-left:0px;margin-right:0px'>\
          <div class='col-lg-12 col-sm-12 col-xs-12' style='padding-left:0px;padding-right:0px'>\
            <div class='databox radius-bordered bg-white' style='height:100%;'>\
              <div class='databox-row'>\
                <div class='databox-cell cell-12 text-align-center bordered-right bordered-platinum' style='min-height:40px;'>\
                  \
                  <div class='databox-stat radius-bordered bg-qin' style='color:#fff;left:7px;right:initial;'>\
                    <div class='stat-text'>"
                      + config.date + "\
                    </div>\
                  </div>\
                  <span class='databox-number lightcarbon'> "
                    + config.title + "\
                  </span>\
                  <span class='databox-number sonic-silver no-margin'>"
                    + config.subtitle + "\
                  </span>\
                  \
                  <div class='databox-stat '>\
                    <div class='stat-text'>\
                      <a href='javascript:void(0);'  onclick='ReportTemplateV2.modal(this, \"search\");' data-title='" + modelTitle + "' data-content='" + config.info + "'>" + "\
                        <span style='font-size:20px;margin-right:30px;' class='qin glyphicon glyphicon-search'></span>\
                      </a>\
                    </div>\
                  </div>\
                  <div class='databox-stat '>\
                    <div class='stat-text'>\
                      <a href='javascript:void(0);'  onclick='ReportTemplateV2.modal(this, \"info\");' data-title='" + modelTitle + "' data-content='" + config.info + "'>" + "\
                        <span style='font-size:20px;' class='qin glyphicon glyphicon-info-sign'></span>\
                      </a>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
      </div>";
    },
    generateInfo: function(outerIndex, innerIndex, config) {
      // return "\
      // <div class='row tab-part tab-part-" + outerIndex + "' style='margin-left:0px;margin-right:0px'>\
      //     <div class='col-lg-12 col-sm-12 col-xs-12' style='padding-left:0px;padding-right:0px'>\
      //       <div class='databox radius-bordered bg-white' style='height:100%;'>\
      //         <div class='databox-row'>\
      //           <div class='databox-cell cell-12 text-align-center bordered-right bordered-platinum' style='min-height:40px;'>\
      //             <span class='databox-number sonic-silver no-margin' style='font-size:13px'>"
      //               + config.text + "\
      //             </span>\
      //           </div>\
      //         </div>\
      //       </div>\
      //     </div>\
      // </div>";

      return "<h5 class='row-title before-qin'>" + config.text + "</h5>";
    },
    generateTemplate: function(outerIndex, template) {
      var parts = template.parts,
          htmlString = "",
          i, len, innerIndex;
      for(i = 0, len = parts.length; i < len; i ++) {
        var part_type = parts[i].type;
        innerIndex = outerIndex * 1000 + i;
        if(part_type === 'banner') {
          htmlString += ReportTemplateV2.generateBanner(outerIndex, innerIndex, parts[i].config);
        }
        else if(part_type === 'tables') {
          htmlString += ReportTemplateV2.generateTables(outerIndex, innerIndex, parts[i].config);
        }
        else if(part_type === 'chart') {
          htmlString += ReportTemplateV2.generateChart(outerIndex, innerIndex, parts[i].config);
        }
        else if(part_type === 'info') {
          htmlString += ReportTemplateV2.generateInfo(outerIndex, innerIndex, parts[i].config);
        }
      }
      return htmlString;
    },
    generateTemplates: function(templates) {
      var tabNav = document.getElementById("tabNav"),
          tabContent = document.getElementById("tabContent"),
          colNum = parseInt(12 / templates.length),
          template,
          i, len;

       tabNav.innerHTML = "";
       tabContent.innerHTML = "";

      for(i = 0, len = templates.length; i < len; i ++) {
        template = templates[i];

        tabNav.innerHTML += "\
          <div class='col-lg-" + colNum + " col-md-" + colNum + " col-sm-" + colNum + " col-xs-" + colNum + "'>\
            <a class='day-container " + (i === 0 ? "highlight" : "") + "' data-index=" + i + ">\
              <div class='day'>"
                + template.title + "\
              </div>\
            </a>\
          </div>";

        tabContent.innerHTML += ReportTemplateV2.generateTemplate(i, template);
      }

      var chartOptions = ReportTemplateV2.charts, chart, chart_id;
      for(i = 0, len = chartOptions.length; i < len; i ++) {
        chart_id = document.getElementById("template_chart_" + chartOptions[i].index);
        if(/3\.1\.\d+/.test(echarts.version)) {
          chart = echarts.init(chart_id, 'macarons');
          console.log('tempalte engine v2: echart ~> 3.1+');
        }
        // "2.2.7"
        else {
          chart = echarts.init(chart_id);
          chart.setTheme('macarons');
          console.log('tempalte engine v2: echart <~ 3.1+');
        }
        chart.setOption(chartOptions[i].options);
      }

      // echarts will not work when its container has 'hidden' class
      for(i = 1, len = templates.length; i < len; i ++) {
        $('.tab-part-' + i).addClass('hidden');
      }

      var modalHtml = '\
        <div class="modal fade in" id="ReportTemplateV2Modal">\
          <div class="modal-dialog">\
            <div class="modal-content">\
              <div class="modal-header">\
                <button aria-label="Close" class="close" data-dismiss="modal" type="button">\
                  <span aria-hidden="true"> ×</span>\
                </button>\
                <h4 class="modal-title">...</h4>\
              </div>\
              <div class="modal-body" style="max-height:500px;overflow:scroll">\
              loading...\
              </div>\
              <div class="modal-footer">\
                <span id="contentType" style="line-height:34px;width:50%;text-align:left;float:left;color:silver;"></span>\
                <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>\
              </div>\
            </div>\
          </div>\
        </div>';

      $(modalHtml).appendTo($("body"));

      // fixed: tab 下表格内容过长而导致样式上的屏幕溢出
      $(".tab-pane table").css({
        "table-layout": "fixed",
        "word-break": "break-all",
        "max-width": ReportTemplateV2.screen().width + "px"
      });
    },
    setSearchItems: function() {
      var items = [];
      for(var i = 0, len = window.TemplateDatas.length; i < len; i++) {
        items.push(window.TemplateDatas[i].name);
      }

      return items[0];
      // window.MobileBridge.setSearchItems(items);
    },
    setSelectedItem: function(selectedItem) {
     $(document).attr("title", selectedItem);

      if(selectedItem && selectedItem.length) {
        window.TemplateDataConfig.selected_item = selectedItem;
        for(var i = 0, len = window.TemplateDatas.length; i < len; i ++) {
          if(window.TemplateDatas[i].name === selectedItem) {
            window.TemplateData.templates = window.TemplateDatas[i].data;
            break;
          }
        }
      }
      ReportTemplateV2.generateTemplates(window.TemplateData.templates);

      $('a.table-more').each(function() {
        var $this = $(this),
            $currentRow = $this.closest('tr'),
            items = $currentRow.nextUntil('tr[class!=more-items]').map(function(){ return 1; }).get();

        if(items === undefined || items.length === 0) {
            $this.addClass('table-more-without-children');
        }
      });

      $('a.table-more').click(function(e) {
        e.preventDefault()

        var $this = $(this),
            $currentRow = $this.closest('tr');
        $currentRow.nextUntil('tr[class!=more-items]').toggle();
        $this.toggleClass('table-more-closed');
      });

      $('a.day-container').click(function(el) {
        el.preventDefault();

        $(".day-container").removeClass("highlight");
        $(this).addClass("highlight");

        var tabIndex = $(this).data("index");
        var klass = ".tab-part-" + tabIndex;
        $(".tab-part").addClass("hidden");
        $(klass).removeClass("hidden");
      });


      $("#ReportTemplateV2Modal").modal("hide");
    }
  }
}).call(this)

window.onerror = function(e) {
  window.alert(e);
}
$(function() {
  var selectedItem = ReportTemplateV2.setSearchItems();
  ReportTemplateV2.setSelectedItem(selectedItem);
});
