/**
 * @name ad engine
 * @version 0.0.1
 * @requires jQuery v1.2.3+
 * @license MIT License - http://www.opensource.org/licenses/mit-license.php
 *
 */
(function(){
  String.prototype.trim=function() {
    return this.replace(/(^\s*)|(\s*$)/g,'');
  }
  window.onerror = function(e) {
    if(window.AndroidJSBridge && window.AndroidJSBridge.jsException) {
      window.AndroidJSBridge.jsException(e);
    }
    else {
      console.log(typeof(e));
      console.log(e);
    }
  }
  window.MobileBridge = {
    htmlError: function(message) {
      if(window.AndroidJSBridge !== undefined && typeof(window.AndroidJSBridge.htmlError) === "function") {
        window.AndroidJSBridge.htmlError(message);
      }
      console.log(message);
    },
    adLink: function(openType, openLink, objectID, objectType, objectTitle) {
      if(window.AndroidJSBridge !== undefined && typeof(window.AndroidJSBridge.adLink) === "function") {
        window.AndroidJSBridge.adLink(openType, openLink, objectID, objectType, objectTitle);
      }
      else {
        var json = {
          'openType': openType,
          'openLink': openLink,
          'objectID': objectID,
          'objectType': objectType,
          'objectTitle': objectTitle
        }
        MobileBridge.htmlError("window.AndroidJSBridge.adLink(): " + JSON.stringify(json) + " not found!");
      }
    }
  }
}).call(this);