/**
 * @name scan bar code engine
 * @version 0.0.1
 * @requires jQuery v1.2.3+
 * @license MIT License - http://www.opensource.org/licenses/mit-license.php
 *
 */
(function() {
  window.AdEngine = {
    adLink: function(adType, adLink) {
      alert("TODO: iOS/Android JavaScript & Native 交互");
    }
  };
}).call(this);
